package com.ticketingApp.LogsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
