package com.ticketingApp.LogsService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogsServiceApplication.class, args);
	}

}
